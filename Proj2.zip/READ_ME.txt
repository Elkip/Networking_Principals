Welcome to my stock buying client-server app
To make files run:
make ALL 

To clean the workspace run:
make clean

After making the files run the following in the order shown
./keymanage
./Broker
./Client

This program was tested on the EMU UNIX Server
